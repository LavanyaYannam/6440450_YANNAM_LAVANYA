// JS Initialization
document.addEventListener('DOMContentLoaded', () => {
  console.log("Welcome to the Community Portal");
  alert("Page fully loaded!");

  const registrationForm = document.getElementById('registrationForm');
  const output = document.getElementById('confirmationMessage');
  const charCount = document.getElementById('charCount');
  const feedback = document.getElementById('feedback');
  const phoneInput = document.getElementById('phone');
  const eventType = document.getElementById('eventType');
  const locationResult = document.getElementById('locationResult');

  // Phone Validation on blur
  phoneInput.addEventListener('blur', () => {
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(phoneInput.value)) {
      alert("Invalid phone number. Please enter 10 digits.");
    }
  });

  // Event Fee on change (demo)
  eventType.addEventListener('change', () => {
    let fee = 0;
    if (eventType.value === "Music") fee = 10;
    if (eventType.value === "Tech") fee = 20;
    if (eventType.value === "Workshop") fee = 5;
    alert(`Selected event fee: $${fee}`);
    localStorage.setItem('preferredEvent', eventType.value);
  });

  // Pre-fill from localStorage
  if (localStorage.getItem('preferredEvent')) {
    eventType.value = localStorage.getItem('preferredEvent');
  }

  // Feedback character counter
  feedback.addEventListener('input', () => {
    charCount.textContent = `${feedback.value.length} characters`;
  });

  // Form submission
  registrationForm.addEventListener('submit', (e) => {
    e.preventDefault();
    output.textContent = "Thank you for registering!";
  });

  // Enlarge image on double-click
  $('.gallery-img').on('dblclick', function () {
    $(this).toggleClass('zoomed');
    $(this).css('transform', 'scale(1.5)');
  });

  // Video canplay
  document.getElementById('promoVideo').addEventListener('canplay', () => {
    document.getElementById('videoStatus').textContent = "Video ready to play!";
  });

  // Warn on leaving unfinished form
  window.onbeforeunload = function () {
    if (feedback.value.length > 0) {
      return "You have unsaved feedback. Are you sure you want to leave?";
    }
  };

  // Geolocation
  document.getElementById('findLocation').addEventListener('click', () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          locationResult.innerHTML = `<strong>Your coordinates:</strong><br>Lat: ${latitude}<br>Long: ${longitude}`;
        },
        (err) => {
          locationResult.textContent = "Location access denied or unavailable.";
        },
        {
          enableHighAccuracy: true,
          timeout: 5000
        }
      );
    } else {
      locationResult.textContent = "Geolocation is not supported by your browser.";
    }
  });

  // Clear Preferences (optional feature)
  const clearBtn = document.createElement('button');
  clearBtn.textContent = "Clear Preferences";
  clearBtn.className = "btn btn-outline-danger ms-3";
  clearBtn.onclick = () => {
    localStorage.clear();
    sessionStorage.clear();
    alert("Preferences cleared.");
  };
  eventType.parentElement.appendChild(clearBtn);
});
