public class task37 {
    public static void main(String[] args) {
        int x = 10 + 20;
        System.out.println(x);
    }
}
