package com.greetings;

import com.utils.Util;

public class Main {
    public static void main(String[] args) {
        Util.sayHi();
    }
}
