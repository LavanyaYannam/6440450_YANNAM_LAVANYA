package com.utils;

public class Util {
    public static void sayHi() {
        System.out.println("Hi from Util!");
    }
}
