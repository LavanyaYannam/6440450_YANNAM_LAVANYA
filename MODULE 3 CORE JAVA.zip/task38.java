public class task38 {
    public void greet() {
        System.out.println("Hello!");
    }

    public static void main(String[] args) {
        new task38().greet();
    }
}
